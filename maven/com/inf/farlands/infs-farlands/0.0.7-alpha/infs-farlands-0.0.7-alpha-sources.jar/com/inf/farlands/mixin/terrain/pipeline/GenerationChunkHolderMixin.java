package com.inf.farlands.mixin.terrain.pipeline;

import com.inf.farlands.InfsFarlands;
import com.inf.farlands.serialize.SectionIO;
import com.inf.farlands.serialize.SectionLifecycle;
import com.inf.farlands.terrain.ChunkBeardifier;
import com.inf.farlands.terrain.LevelSystems;
import com.inf.farlands.terrain.biomeFiller.BiomeFiller;
import com.inf.farlands.terrain.debug.StageMetrics;
import com.inf.farlands.terrain.decorationFiller.DecorationFiller;
import com.inf.farlands.terrain.pipeline.GenQueue;
import com.inf.farlands.terrain.pipeline.Scheduler;
import com.inf.farlands.terrain.structure.StructureDriver;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

import net.minecraft.server.level.ChunkMap;
import net.minecraft.server.level.ChunkResult;
import net.minecraft.server.level.FullChunkStatus;
import net.minecraft.server.level.GenerationChunkHolder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Util;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ImposterProtoChunk;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.ProtoChunk;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.level.levelgen.Beardifier;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 地形管线：拦截 vanilla chunk 生成调度，短路到 FULL 空壳。
 *
 * 所有 chunk 生成入口，即 getChunk 任意状态请求与 ChunkHolder 的 prepare 链，都汇聚到
 * scheduleChunkGenerationTask。拦截后不创建 ChunkGenerationTask，生成金字塔一行不跑，改为
 * 读盘或建空壳 ProtoChunk，构造 LevelChunk，逐状态 completeFuture，于是全部请求立即拿到
 * LevelChunk。per-section 生成由独立的 terrain 管线异步驱动。
 *
 * 26.1.2 的 vanilla 方法体内有 task 与 applyStep 机制，本覆写整体替换它且从不设置 task，
 * 因此 ChunkGenerationTask 永不创建，金字塔不会被旁路驱动。
 *
 * 线程：拦截在主线程；scheduleChunkLoad 内部后台读盘加主线程建 ProtoChunk；thenAccept 跟随主线程。
 */
@Mixin(GenerationChunkHolder.class)
public abstract class GenerationChunkHolderMixin {

    // startedWork 必须置 FULL，否则 getLatestChunk 返回 null，saveChunkIfNeeded 永不保存。
    // final 字段用 @Shadow 非 final 声明，mixin 生成 putfield 直写，绕开反射写 final 的限制。
    @Shadow
    private AtomicReference<ChunkStatus> startedWork;

    @Shadow
    public abstract ChunkPos getPos();

    @Shadow
    public abstract FullChunkStatus getFullStatus();

    /**
     * 建 holder 不再受 {@code ChunkPos.isValid} 约束。
     *
     * <p>
     * 同一个谓词有两个身份：{@code Level.isInValidBounds} 的读写门，与这个构造器里的建造型断言。读写门那一侧
     * 现在按可玩段界判，界外坐标不该发出区块请求；但 holder 本身必须能在 {@code MAX_SECTION} 那一圈建出来，
     * 因为票圈与窗口都把界夹到那里。两件事混在一个谓词里，窄化就会重演实测过的
     * {@code Trying to create chunk out of reasonable bounds}，出生区准备失败、登录中止。
     *
     * <p>
     * 所以这里把两个用法拆开：读写的界由 {@code isValid} 判，建 holder 的界不判。javap 核过，本类里
     * {@code ChunkPos.isValid()} 只有构造器里那一次调用，不会波及别的判据。
     */
    @Redirect(method = "<init>(Lnet/minecraft/world/level/ChunkPos;)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/ChunkPos;isValid()Z"))
    private boolean farlands$allowAnyChunkPos(ChunkPos pos) {
        return true;
    }

    private static final Method M_SCHEDULE_CHUNK_LOAD;
    private static final Field F_LEVEL;
    private static final Method M_GET_OR_CREATE_FUTURE;
    private static final Method M_COMPLETE_FUTURE;
    private static final Method M_IS_STATUS_DISALLOWED;

    static {
        try {
            M_SCHEDULE_CHUNK_LOAD = ChunkMap.class.getDeclaredMethod("scheduleChunkLoad", ChunkPos.class);
            M_SCHEDULE_CHUNK_LOAD.setAccessible(true);
            F_LEVEL = ChunkMap.class.getDeclaredField("level");
            F_LEVEL.setAccessible(true);
            M_GET_OR_CREATE_FUTURE = GenerationChunkHolder.class.getDeclaredMethod("getOrCreateFuture",
                    ChunkStatus.class);
            M_GET_OR_CREATE_FUTURE.setAccessible(true);
            M_COMPLETE_FUTURE = GenerationChunkHolder.class.getDeclaredMethod("completeFuture", ChunkStatus.class,
                    ChunkAccess.class);
            M_COMPLETE_FUTURE.setAccessible(true);
            M_IS_STATUS_DISALLOWED = GenerationChunkHolder.class.getDeclaredMethod("isStatusDisallowed",
                    ChunkStatus.class);
            M_IS_STATUS_DISALLOWED.setAccessible(true);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Unique
    private AtomicBoolean farlandsExistenceStarted;

    /**
     * 延迟创建标志，不用字段初始化器。本类没有显式构造器，@Unique 实例字段的初始化器可能被静默
     * 丢弃，读到时会是 null。
     */
    @Unique
    private AtomicBoolean farlandsExistence() {
        AtomicBoolean b = this.farlandsExistenceStarted;
        if (b == null) {
            b = new AtomicBoolean();
            this.farlandsExistenceStarted = b;
        }
        return b;
    }

    /** 每 holder 短路只跑一次。completeFuture 对已成功完成的 future 再 complete 会抛。 */
    @Overwrite
    public CompletableFuture<ChunkResult<ChunkAccess>> scheduleChunkGenerationTask(ChunkStatus targetStatus,
            ChunkMap chunkMap) {
        if (farlandsIsStatusDisallowed(targetStatus)) {
            return GenerationChunkHolder.UNLOADED_CHUNK_FUTURE;
        }
        CompletableFuture<ChunkResult<ChunkAccess>> future = farlandsGetOrCreateFuture(targetStatus);
        if (future.isDone()) {
            return future;
        }
        if (farlandsExistence().compareAndSet(false, true)) {
            ChunkPos pos = this.getPos();
            try {
                CompletableFuture<ChunkAccess> load = farlandsScheduleChunkLoad(chunkMap, pos);
                load.thenAccept(proto -> this.farlandsCompleteEmpty(chunkMap, proto));
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return future;
    }

    /** 主线程：ProtoChunk 转 LevelChunk 容器构造，生命周期，逐状态 completeFuture。 */
    @Unique
    private void farlandsCompleteEmpty(ChunkMap chunkMap, ChunkAccess proto) {
        try {
            ServerLevel level = (ServerLevel) F_LEVEL.get(chunkMap);
            boolean isNew = !(proto instanceof ImposterProtoChunk);
            LevelChunk levelchunk;
            if (!isNew) {
                levelchunk = ((ImposterProtoChunk) proto).getWrapped();
            } else {
                levelchunk = new LevelChunk(level, (ProtoChunk) proto, p -> {
                });
            }
            levelchunk.setFullStatus(this::getFullStatus);
            levelchunk.runPostLoad();
            levelchunk.setLoaded(true);
            levelchunk.registerAllBlockEntitiesAfterLevelLoad();
            levelchunk.registerTickContainerInLevel(level);

            this.startedWork.set(ChunkStatus.FULL);

            // FULL 不在这里完成：它的门现在是数据就绪，由 ChunkReadiness 在就绪时补。只置到 SPAWN，
            // getLatestChunk 在当前状态 future 未完成时回退到父状态，因此仍返回这个 LevelChunk，
            // 存盘与 fsa 的遍历不受影响。
            for (ChunkStatus status : ChunkStatus.getStatusList()) {
                if (status == ChunkStatus.FULL) {
                    continue;
                }
                farlandsCompleteFuture(status, levelchunk);
            }
            // 这一格的壳出现了：等它的装饰项要重判门，等它的结构引用相要重判 ±8。
            DecorationFiller.cellChanged(level, levelchunk.getPos().pack());
            StructureDriver.cellChanged();

            // 结构相早于 Beardifier，Beardifier 早于 fill。这是铁的顺序，但它只约束 fill，不约束就绪。
            // 所以这里只做起点相，引用相与 Beardifier 的时机交给调度器的准入：准入判 hasBeardifier 为假
            // 时，若 referencesBuildable 就现场建，建完再提交一次。
            //
            // 起点相归地物族：自己算还是走宿主基座、这一族要不要走结构相，都由族回答，见
            // {@code DecorationSystem#createStructures}。返回假表示按无结构处理：那时起点表为空，而
            // forStructuresInChunk 对空起点表返回的就是 Beardifier.EMPTY。照调它而不是直接塞 EMPTY，
            // 是为了不让这里成为唯一算得出特例的地方。
            //
            // 两道与内容无关的安全门放在调用点，任何族都绕不过：维度关掉结构生成的，以及可玩界之外的
            // chunk。后者没有可玩方块，起点相也不该跑，取到的是同一个 EMPTY。
            boolean mayHaveStructures = StructureDriver.structuresEnabled(level)
                    && StructureDriver.inStructureRange(levelchunk);
            boolean hasStructures = mayHaveStructures
                    && ((LevelSystems) level).decorationSystem().createStructures(level, levelchunk);
            if (!hasStructures) {
                ((ChunkBeardifier) levelchunk).setBeardifier(
                        Beardifier.forStructuresInChunk(level.structureManager(), levelchunk.getPos()));
            }
            farlandsGenerateTail(level, levelchunk);
        } catch (Exception e) {
            InfsFarlands.LOGGER.error("farlands: existence flow failed chunk={}", proto.getPos(), e);
            throw new RuntimeException(e);
        }
    }

    /**
     * 结构相的引用段：引用相，然后 Beardifier。由调度器的准入按需调，见 {@code Scheduler.admit}。
     *
     * <p>必须在主线程：结构放置与 Beardifier 都经 StructureManager 走 ServerChunkCache 的取 chunk。
     */
    @Unique
    private void farlandsStructureReady(ServerLevel level, LevelChunk levelchunk) {
        // 引用相：读中心 ±8 的起点表，写中心自己的引用表。主线程调，且必须先于 Beardifier。
        StructureDriver.buildReferences(level, levelchunk);

        // 结构性地形适配数据：Beardifier.forStructuresInChunk 读中心的引用表，再按引用取各 chunk 的
        // 起点，所以必须在引用相之后。它经 StructureManager 走 ServerChunkCache 的取 chunk，非主线程
        // 上那条路把活踢回主线程并阻塞等待，所以必须在主线程算，此处就是主线程。
        ((ChunkBeardifier) levelchunk).setBeardifier(
                Beardifier.forStructuresInChunk(level.structureManager(), levelchunk.getPos()));

        // 建完引用相即可交回准入：TERRAIN 的依赖是 hasBeardifier，调度器会再提交一次。
        Scheduler.submit(levelchunk);
    }

    /**
     * 结构相之后照跑的那一支：biome、fsa 读回、交准入。
     *
     * <p>它不依赖 {@code Beardifier}，所以结构相被延后时也照跑。加载期的 FULL 由调度器的第七行补，
     * 而 {@code setInitialSpawn} 的阻塞读早于预加载循环，所以这条链必须在存在流程内跑完。
     */
    @Unique
    private void farlandsGenerateTail(ServerLevel level, LevelChunk levelchunk) {
        StageMetrics.chunkLoaded(levelchunk.getPos().pack());
        // biome 阶段独立：后台按窗口并集填 biome 并升 BIOMES，完成后回主线程做 fsa 读回，
        // 读回完成再入生成队列。读回与入队必须回主线程，thenAccept 在后台线程执行。
        //
        // biome 阶段不在生成与光照两张标志内，而它同样会换掉 section 的 biomes 容器，发送侧
        // 据此另查 isBiomeFilling。begin 必须在提交之前由本线程落下，end 必须在填充的最后一笔
        // 写之后：填充抛异常或提交本身失败都要清，否则该 chunk 永久为忙。
        GenQueue.beginBiomeFill(levelchunk);
        // 视距之外不铺群系：为别的 chunk 的 ±8 被钉住加载的壳也落在这一片，它们不会被驱动，铺了也白做。
        // 它们的段停在 UNPROCESSED，而 collectSegments 的判据是「未过 TERRAIN」，照样会收，真群系由
        // GenTask 的预填补上，下发要求 LIGHTED 所以不受影响。判据在主线程取一次：读回与入队照走，而
        // players 是普通 List，后台线程不该遍历它。
        boolean prefill = GenQueue.isNearPlayer(levelchunk);
        try {
            CompletableFuture.runAsync(
                    () -> {
                        boolean filled = false;
                        try {
                            if (prefill) {
                                BiomeFiller.fillChunkBiomes(level, levelchunk);
                            }
                            filled = true;
                        } finally {
                            if (!filled) {
                                GenQueue.endBiomeFill(levelchunk);
                            }
                        }
                    },
                    Util.backgroundExecutor())
                    .thenAccept(v -> SectionIO.runOnMainThread(() -> {
                        // 群系在途标志与读回在同一次主线程任务里交接。若在后台线程就清掉标志，
                        // 从清掉到 loadChunkSections 落下读回标记之间会出现一个既无在途也无读回的
                        // 缝，ChunkReadiness 会把这个缝判成就绪。
                        GenQueue.endBiomeFill(levelchunk);
                        // 群系标志清掉后，一个已读回且已点亮的 chunk 可能刚好就绪，交准入。
                        Scheduler.submit(levelchunk);
                        // fsa 读回：先查磁盘窗口内 section，有则读回恢复数据、光照、stage 并补发。
                        // 完成后才 enqueueChunk，collectSegments 的 isOrAfter(TERRAIN) 自动跳过已读回的，
                        // 磁盘没有的 section 正常入生成队列。
                        SectionLifecycle.loadChunkSections(levelchunk, () -> {
                            StageMetrics.chunkLoadDone();
                            GenQueue.enqueueChunk(levelchunk);
                        });
                    }, level));
        } catch (RuntimeException e) {
            GenQueue.endBiomeFill(levelchunk);
            throw e;
        }
    }

    /**
     * 上报口径改按「存在流程跑过」算。
     *
     * <p>模板按「该状态对应的 chunk 是否存在」逐级回退，而 FULL 的 future 在 port 里被数据就绪悬着，
     * 于是这里一路回退成 SPAWN。ChunkLoadCounter 判的是等于 FULL，prepareLevels 与入场准备都会因此
     * 永不收敛，客户端的 chunk 网格也一格都画不出来。只改上报，数据门仍在 future 上。
     */
    @Inject(method = "getLatestStatus", at = @At("RETURN"), cancellable = true)
    private void farlands$reportFull(CallbackInfoReturnable<ChunkStatus> cir) {
        if (this.startedWork.get() == ChunkStatus.FULL) {
            cir.setReturnValue(ChunkStatus.FULL);
        }
    }

    @Unique
    private boolean farlandsIsStatusDisallowed(ChunkStatus status) {
        try {
            return (Boolean) M_IS_STATUS_DISALLOWED.invoke(this, status);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @SuppressWarnings("unchecked")
    @Unique
    private CompletableFuture<ChunkResult<ChunkAccess>> farlandsGetOrCreateFuture(ChunkStatus status) {
        try {
            return (CompletableFuture<ChunkResult<ChunkAccess>>) M_GET_OR_CREATE_FUTURE.invoke(this, status);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Unique
    private void farlandsCompleteFuture(ChunkStatus status, ChunkAccess chunk) {
        try {
            M_COMPLETE_FUTURE.invoke(this, status, chunk);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @SuppressWarnings("unchecked")
    @Unique
    private static CompletableFuture<ChunkAccess> farlandsScheduleChunkLoad(ChunkMap chunkMap, ChunkPos pos) {
        try {
            return (CompletableFuture<ChunkAccess>) M_SCHEDULE_CHUNK_LOAD.invoke(chunkMap, pos);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
