package com.inf.farlands.register;

import com.inf.farlands.InfsFarlands;
import com.inf.farlands.simulation.int64.system.terrain.noise.misc.Void.VoidSimulationNoiseSystem;
import com.inf.farlands.simulation.registry.SimulationRegistries;
import com.inf.farlands.command.FarlandsCommandRegistry;
import com.inf.farlands.compat.chunky.ChunkyPregen;
import com.inf.farlands.register.command.FarLandsCommands;
import com.inf.farlands.register.packet.*;
import com.inf.farlands.terrain.registry.SystemRegistries;
import com.inf.farlands.terrain.system.biome.misc.Void.VoidBiomeSystem;
import com.inf.farlands.terrain.system.biome.overworld.Vanilla.VanillaBiomeSystem;
import com.inf.farlands.terrain.system.carver.misc.Void.VoidCarverSystem;
import com.inf.farlands.terrain.system.carver.overworld.Vanilla.VanillaCarverSystem;
import com.inf.farlands.terrain.system.common.overworld.Vanilla.VanillaFamilySeed;
import com.inf.farlands.terrain.system.decoration.misc.Void.VoidDecorationSystem;
import com.inf.farlands.terrain.system.decoration.overworld.Vanilla.VanillaDecorationSystem;
import com.inf.farlands.terrain.system.surface.misc.Void.VoidSurfaceSystem;
import com.inf.farlands.terrain.system.surface.overworld.Vanilla.VanillaSurfaceSystem;
import com.inf.farlands.terrain.system.terrain.noise.misc.Void.VoidNoiseSystem;
import com.inf.farlands.terrain.system.terrain.noise.overworld.Vanilla.VanillaNoiseSystem;
import com.inf.farlands.terrain.system.terrain.section.misc.Void.VoidSectionSystem;

public class FarlandsRegister {

    /** payload 类型是否已登记。模组初始化与三处 codec 构造点都会调，可能来自不同线程。 */
    private static boolean payloadTypesRegistered;

    public static void registerStatic() {
        registerPayloadTypes("mod-init");
        registerSystems();
        // 空框 seed 的会话边界是进页。登记由状态的所有者自己发起，界面只负责发那个公开钩子。
        VanillaFamilySeed.registerPageHook();
    }

    /**
     * 登记六个自定义 payload 类型，只做一次。
     *
     * <p>两个来源：模组初始化，以及 {@code ClientboundCustomPayloadPacket} 与
     * {@code ServerboundCustomPayloadPacket} 的 {@code <clinit>} 里那三处 codec 构造点。分发表在那三个点上
     * 一次性建好，内容取自 Commonbounds／Serverbounds 的当时内容，所以谁先触发那个 {@code <clinit>}，
     * 快照就是谁的时机。装了会在自己模组初始化期碰这两个类的模组（Fabric API 的 networking 模块就是）时，
     * {@code <clinit>} 就早于本模组的初始化，快照拍到空表，本模组的包全部落回 DiscardedPayload，发包抛
     * ClassCastException。故三处构造点也负责把表填好，使这件事与任何第三方模组的初始化顺序无关。
     *
     * <p>必须整体上锁：clientbound 的 {@code <clinit>} 在渲染线程，serverbound 的在 Netty 线程，两个方向的
     * 表可能并发构造，check-then-act 会双填，而重复 id 会让 CustomPacketPayload.codec 的
     * toUnmodifiableMap 抛 Duplicate key。
     *
     * @param source 触发来源，只用于日志；第一个调用者的来源会留下，便于事后判别是顺序问题还是别的。
     */
    public static void registerPayloadTypes(String source) {
        synchronized (FarlandsRegister.class) {
            if (payloadTypesRegistered) {
                return;
            }
            payloadTypesRegistered = true;
            InfsFarlands.LOGGER.info("farlands: registered custom payload types from {}", source);
            ChunkDataPacketRegister.registerType();
            ClampStatePacketRegister.registerType();
            ClampTogglePacketRegister.registerType();
            ExactPositionPacketRegister.registerType();
            ExactClientPositionPacketRegister.registerType();
            LightUpdatePacketRegister.registerType();
            SectionBlocksUpdatePacketRegister.registerType();
            SystemsPacketRegister.registerType();
            SimulationSectionPacketRegister.registerType();
            SimulationSystemsPacketRegister.registerType();
        }
    }

    /** 内置系统按族登记，id 与实现类的对应关系集中在此。 */
    private static void registerSystems() {
        // 模拟层一个内置系统。登记必须在世界加载之前：档案在 level 构造时才解析。
        SimulationRegistries.register(SimulationRegistries.NOISE_VOID, VoidSimulationNoiseSystem.class);
        SystemRegistries.registerTerrain(SystemRegistries.TERRAIN_MISC_VOID_NOISE_SYSTEM, VoidNoiseSystem.class);
        SystemRegistries.registerTerrain(SystemRegistries.TERRAIN_MISC_VOID_SECTION_SYSTEM,
                VoidSectionSystem.class);
        SystemRegistries.registerTerrain(SystemRegistries.TERRAIN_OVERWORLD_VANILLA_NOISE_SYSTEM,
                VanillaNoiseSystem.class);
        SystemRegistries.registerTerrain(SystemRegistries.TERRAIN_THE_NETHER_VANILLA_NOISE_SYSTEM,
                com.inf.farlands.terrain.system.terrain.noise.theNether.Vanilla.VanillaNoiseSystem.class);
        SystemRegistries.registerTerrain(SystemRegistries.TERRAIN_THE_END_VANILLA_NOISE_SYSTEM,
                com.inf.farlands.terrain.system.terrain.noise.theEnd.Vanilla.VanillaNoiseSystem.class);

        SystemRegistries.registerBiome(SystemRegistries.BIOME_MISC_VOID_BIOME_SYSTEM, VoidBiomeSystem.class);
        SystemRegistries.registerBiome(SystemRegistries.BIOME_OVERWORLD_VANILLA_BIOME_SYSTEM,
                VanillaBiomeSystem.class);
        SystemRegistries.registerBiome(SystemRegistries.BIOME_THE_NETHER_VANILLA_BIOME_SYSTEM,
                com.inf.farlands.terrain.system.biome.theNether.Vanilla.VanillaBiomeSystem.class);
        SystemRegistries.registerBiome(SystemRegistries.BIOME_THE_END_VANILLA_BIOME_SYSTEM,
                com.inf.farlands.terrain.system.biome.theEnd.Vanilla.VanillaBiomeSystem.class);

        SystemRegistries.registerSurface(SystemRegistries.SURFACE_MISC_VOID_SURFACE_SYSTEM,
                VoidSurfaceSystem.class);
        SystemRegistries.registerSurface(SystemRegistries.SURFACE_OVERWORLD_VANILLA_SURFACE_SYSTEM,
                VanillaSurfaceSystem.class);
        SystemRegistries.registerSurface(SystemRegistries.SURFACE_THE_NETHER_VANILLA_SURFACE_SYSTEM,
                com.inf.farlands.terrain.system.surface.theNether.Vanilla.VanillaSurfaceSystem.class);
        SystemRegistries.registerSurface(SystemRegistries.SURFACE_THE_END_VANILLA_SURFACE_SYSTEM,
                com.inf.farlands.terrain.system.surface.theEnd.Vanilla.VanillaSurfaceSystem.class);

        SystemRegistries.registerCarver(SystemRegistries.CARVER_MISC_VOID_CARVER_SYSTEM,
                VoidCarverSystem.class);
        SystemRegistries.registerCarver(SystemRegistries.CARVER_OVERWORLD_VANILLA_CARVER_SYSTEM,
                VanillaCarverSystem.class);
        SystemRegistries.registerCarver(SystemRegistries.CARVER_THE_NETHER_VANILLA_CARVER_SYSTEM,
                com.inf.farlands.terrain.system.carver.theNether.Vanilla.VanillaCarverSystem.class);
        SystemRegistries.registerCarver(SystemRegistries.CARVER_THE_END_VANILLA_CARVER_SYSTEM,
                com.inf.farlands.terrain.system.carver.theEnd.Vanilla.VanillaCarverSystem.class);

        SystemRegistries.registerDecoration(SystemRegistries.DECORATION_MISC_VOID_DECORATION_SYSTEM,
                VoidDecorationSystem.class);
        SystemRegistries.registerDecoration(SystemRegistries.DECORATION_OVERWORLD_VANILLA_DECORATION_SYSTEM,
                VanillaDecorationSystem.class);
        SystemRegistries.registerDecoration(SystemRegistries.DECORATION_THE_NETHER_VANILLA_DECORATION_SYSTEM,
                com.inf.farlands.terrain.system.decoration.theNether.Vanilla.VanillaDecorationSystem.class);
        SystemRegistries.registerDecoration(SystemRegistries.DECORATION_THE_END_VANILLA_DECORATION_SYSTEM,
                com.inf.farlands.terrain.system.decoration.theEnd.Vanilla.VanillaDecorationSystem.class);
    }

    public static void register() {
        ClampTogglePacketRegister.registerHandler();
        ExactClientPositionPacketRegister.registerHandler();
        // 命令监听器只在此登记一次；Commands 每次重建（含数据包 reload）时由 CommandsMixin 统一 fire。
        FarlandsCommandRegistry.registerServer(FarLandsCommands::register);
        // Chunky 兼容层：装了它才登记命令与每 tick 钩子，没装时本调用直接返回。
        ChunkyPregen.init();
    }
}
