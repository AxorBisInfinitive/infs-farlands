package com.inf.farlands;

import com.inf.farlands.light.FarLandsLightEngine;
import com.inf.farlands.serialize.SectionIO;
import com.inf.farlands.serialize.SectionLifecycle;
import com.inf.farlands.simulation.SimulationLifecycle;
import com.inf.farlands.simulation.SimulationServer;
import com.inf.farlands.simulation.model.SimulationConfig;
import com.inf.farlands.terrain.LevelSystems;
import com.inf.farlands.terrain.debug.StageMetrics;
import com.inf.farlands.terrain.pipeline.NeighborhoodTickets;
import com.inf.farlands.terrain.pipeline.Scheduler;
import com.inf.farlands.terrain.system.terrain.noise.overworld.Vanilla.VanillaNoiseSystem;
import com.inf.farlands.util.maps.AquiferUtil;
import com.inf.farlands.util.maps.BlockUtil;
import com.inf.farlands.util.maps.SectionUtil;
import com.inf.farlands.util.network.ChunkDataSender;
import com.inf.farlands.util.network.SimulationSystemsSender;
import com.inf.farlands.util.network.SystemsSender;
import com.inf.farlands.util.window.EntitySectionWindow;
import com.inf.farlands.util.window.PlayerTable;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.PlayerAdvancements;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

public class FarlandsTick {
    private static final int INTERVAL = 200;
    private static volatile int now = 0;

    public static int getNow() {
        return now;
    }

    /**
     * 上一轮 fsa 清理是否因预算耗尽而没做完。窗口静止时窗口并集不再变化，只按 windowChanged 触发会让
     * 没清完的积压一直留着，所以未清完就下 tick 续跑。预算耗尽只由「已点亮、脏、待入队」的段超出上限
     * 引起，释放那一支不扣预算，因此清完之后本标记恒假，不会常驻扫描。
     */
    private static boolean cleanupOpen;

    /**
     * 当前的 server 实例。写点在 level 构造末尾与每个 tick 末尾，读点在阻塞等待的泵里。
     *
     * <p>
     * 泵挂的是 {@code BlockableEventLoop.managedBlock}，它同时被服务端主执行器与 chunk 源的主线程执行器
     * 继承。后者的等待不是 {@code MinecraftServer}，而同步取区块正是卡在它上面，那里拿不到 server，
     * 所以显式登记一份，泵按它判线程。关服时置空，不留旧世界的引用。
     */
    private static volatile MinecraftServer runningServer;

    /** 登记当前的 server。写点：level 构造末尾与每个 tick 末尾。 */
    public static void setRunningServer(MinecraftServer server) {
        runningServer = server;
    }

    /** 当前登记的 server，没有则为 null。供阻塞等待的泵取用。 */
    public static MinecraftServer runningServer() {
        return runningServer;
    }

    /**
     * 单一时钟的写入点：服务端 tick 与分离 JVM 的客户端 tick 都从这里推进，侧信道打戳读的
     * 就是这个值。
     */
    public static void setNow(int tickCount) {
        now = tickCount;
    }

    private static void swapBlockLookup(MinecraftServer server, int tickCount) {
        // size 必须在 swap 前取：swap 之后读到的是新的空表，恒为 0。
        int size = BlockUtil.size();
        if (FarlandsConfig.logBlockLookupSwap) {
            InfsFarlands.LOGGER.info("Swapping BlockUtil.lookup, size: {}", size);
        }
        BlockUtil.swap();
        if (size > 0) {
            awardIntBlockPos(server);
        }
    }

    /**
     * 这一轮在 swap 之前至少注册过一个坐标时，给所有在线玩家授予成就。
     * 对应进度的 criterion 是 minecraft:impossible，永不自动满足，只能由本方法授予。
     * award 对已解锁的玩家是幂等的。
     */
    private static void awardIntBlockPos(MinecraftServer server) {
        AdvancementHolder holder = server.getAdvancements().get(InfsFarlands.id("int-block-pos"));
        if (holder == null) {
            return;
        }
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.getAdvancements().award(holder, "impossible");
        }
    }

    public static void trimSectionLookup(int tickCount) {
        int beforeSize = SectionUtil.size();
        SectionUtil.trim(tickCount);
        int afterSize = SectionUtil.size();
        if (FarlandsConfig.logSectionLookupTrim) {
            InfsFarlands.LOGGER.info("Trimmed SectionUtil.lookup, before: {}, after: {}", beforeSize, afterSize);
        }
    }

    private static void trimAquiferLookup(int tickCount) {
        int beforeSize = AquiferUtil.size();
        AquiferUtil.trim(tickCount);
        int afterSize = AquiferUtil.size();
        if (FarlandsConfig.logAquiferLookupTrim) {
            InfsFarlands.LOGGER.info("Trimmed AquiferUtil.lookup, before: {}, after: {}", beforeSize, afterSize);
        }
    }

    /**
     * 该维度出现 vanilla 噪声系统时，给还在世上的玩家补发进度与经验。
     *
     * <p>
     * 不能在 VanillaNoiseSystem 构造时发：它跑在 createLevels 里，那时玩家还没进世界，
     * 专用服务器上第一个玩家可能在播种之后很久才登录。这里每 tick 检查，按完成前后各读一次
     * isDone 判定，只在完成的那一 tick 给一次经验。
     */
    private static void awardNewVanillaNoiseSystem(MinecraftServer server) {
        AdvancementHolder holder = server.getAdvancements().get(InfsFarlands.id("new-vanilla-noise-system"));
        if (holder == null) {
            return;
        }
        for (ServerLevel level : server.getAllLevels()) {
            if (((LevelSystems) level).terrainSystem() instanceof VanillaNoiseSystem) {
                for (ServerPlayer player : level.players()) {
                    PlayerAdvancements advancements = player.getAdvancements();
                    AdvancementProgress progress = advancements.getOrStartProgress(holder);
                    boolean wasDone = progress.isDone();

                    advancements.award(holder, "impossible");
                    if (!wasDone && progress.isDone()) {
                        player.giveExperiencePoints(64);
                    }
                }
            }
        }
    }

    /**
     * 每 tick 末尾要跑一次的钩子，由兼容层在自己初始化时登记。核心不认识登记者，也不 import 它。
     *
     * <p>用途是那些「需要每 tick 推进一步、但又不属于本类职责」的兼容逻辑，例如 Chunky 预生成的驱动
     * 与完成判定。登记发生在模组初始化期，那时是单线程，此后只读。
     */
    private static final List<Consumer<MinecraftServer>> TICK_SINKS = new CopyOnWriteArrayList<>();

    /** 登记一个每 tick 末尾的回调。 */
    public static void addTickSink(Consumer<MinecraftServer> sink) {
        TICK_SINKS.add(sink);
    }

    /**
     * 只刷驱动玩家表与实体 section 窗口并集。
     *
     * <p>准入的两道门读的就是这两张：{@code isNearPlayer} 读表，{@code Scheduler.sectionsFor} 的竖直面
     * 读窗口并集。抽出来的理由是提交点也要能只刷这一层：提交发生在阻塞取数之内，而票据的加减不该跟着
     * 提前到那一处。
     *
     * <p>表也在这里重建，因为 {@code refreshTickState} 有三个调用者，其中两个不走
     * {@code driveWindowAndTerrain}：阻塞取数的泵与换维度时的提交。把它们漏掉，那两个路径就会读到旧表。
     */
    public static void refreshGates(MinecraftServer server) {
        PlayerTable.refresh(server);
        EntitySectionWindow.update(PlayerTable.entries());
    }

    /**
     * 每 tick 的三步刷新：驱动玩家表、窗口并集，加驱动面 ±8 的保加载票。
     *
     * <p>抽成方法是为了让真 tick 的末尾与阻塞等待期的泵共用同一份顺序。两处各写一份顺序，就会刷出与真
     * tick 不同源的状态，而两边同时被准入读。
     */
    public static void refreshTickState(MinecraftServer server) {
        refreshGates(server);
        NeighborhoodTickets.tick(server, PlayerTable.entries());
    }

    /** 服务端 tick 末尾统一入口。 */
    public static void atEnd(MinecraftServer server, int tickCount) {
        setRunningServer(server);
        setNow(tickCount);
        awardNewVanillaNoiseSystem(server);
        if (tickCount % INTERVAL == 0) {
            swapBlockLookup(server, tickCount);
            trimSectionLookup(tickCount);
            trimAquiferLookup(tickCount);
            // 就绪吞吐读数：与本周期同档，约 10 秒一行。只报读数，不报解读。
            StageMetrics.flush();
            // 视距内兜底重扫：把有活却不在候选表里的 chunk 补交一次，本拍末尾的 tick 统一派发。
            com.inf.farlands.terrain.pipeline.InViewSweep.run(server);
        }
        // 世界系统选择下发：玩家进服或换维度后补一次，客户端据此显示当前 level 用哪五族系统。
        SystemsSender.tick(server);
        // 模拟层的选择同理，只有一族，走自己那条下发。
        SimulationSystemsSender.tick(server);
        // 周期持久化：窗口内脏 section 写盘；偏移表与数据同节奏落盘，否则运行中磁盘偏移表
        // 陈旧，重进时 getSlot 错位丢 section。崩溃与强退兜底。
        //
        // 排在窗口差量之前：清理会把窗口外已点亮的段以 CLEANUP 语义收走，持久化必须先入队。
        if (tickCount % FarlandsConfig.fsaPersistInterval == 0) {
            SectionLifecycle.flushAllDirty(server);
            SectionIO.flushAllOffsetTables();
        }
        // 模拟段的周期落盘。与窗口清理同理，是崩溃与强退的兜底；自成一个间隔，不复用 fsa 那条。
        if (tickCount % SimulationConfig.ssaPersistInterval == 0) {
            SimulationLifecycle.flushAllDirty(server);
        }
        // 窗口差量、窗口外清理与派发，与阻塞等待期共用同一段，顺序与理由见 driveWindowAndTerrain。
        driveWindowAndTerrain(server);
        // 模拟段的下发：读本 tick 已刷新的窗口与玩家表，所以在窗口驱动之后。
        SimulationServer.tick(server);
        // 兼容层的每 tick 钩子，排在所有核心驱动之后：它只驱动本 port 之外的请求方，例如 Chunky 预生成。
        for (Consumer<MinecraftServer> sink : TICK_SINKS) {
            sink.accept(server);
        }
    }

    /**
     * 窗口差量、窗口外清理与派发这一段，每个 tick 末尾与阻塞等待期共用。
     *
     * <p>
     * 共用的理由是一条时序。{@code FULL} 只由调度器补，而补它之前要先把这个 chunk 的窗口面读过一次盘、把
     * 它的候选放回表，这两件事起于 {@link ChunkDataSender#tick} 的窗口差量。阻塞取数发生在 tick 之内，
     * tick 末尾的 {@link #atEnd} 到不了，于是主线程在等一个只有 tick 末尾才会推进的状态。等待期的泵因此
     * 必须调同一段，否则候选被丢掉的那一格永远补不上 FULL，等待也就永远解不开。
     *
     * <p>
     * 顺序是契约。窗口差量置玩家移动标志并起窗口读回，随后按该标志重建各维光照队列；然后刷新两条门，
     * 清理遍历的是窗口并集，所以排在刷新之后；派发最后，它读快照与窗口并集。周期持久化不在这一段里，
     * 它要排在清理之前，由调用方排。
     *
     * <p>
     * 等待在同一 tick 中途解开时，本方法会在该 tick 里被跑两次：窗口差量与清理的预算各翻一倍，状态不变。
     *
     * <p>
     * 线程与节奏由调用方负责：只在服务端线程调，等待期的调用按墙钟节流。
     */
    public static void driveWindowAndTerrain(MinecraftServer server) {
        // 驱动玩家表必须先于窗口差量：差量按表里的段中心算新窗口，读旧表会把界外玩家当成还在界内。
        PlayerTable.refresh(server);
        // 窗口差量与限量发包；返回值同时驱动 fsa 的窗口清理判定。
        boolean windowChanged = ChunkDataSender.tick(server, PlayerTable.entries());
        // 玩家跨 chunk 移动时，光照队列按当前距离重排。地形侧的候选表在准入时按快照排序，不需要重排。
        if (ChunkDataSender.consumePlayersMoved()) {
            for (ServerLevel level : server.getAllLevels()) {
                if (level.getChunkSource().getLightEngine() instanceof FarLandsLightEngine lightEngine) {
                    lightEngine.rebuildLightQueue();
                }
            }
        }
        // 玩家快照、窗口并集与驱动面票圈，同一份玩家列表、同一时点落地。
        refreshTickState(server);
        // 窗口变化：窗口之外的 section 按档处置，上限 CLEANUP_BUDGET/tick。
        // 未清完则下 tick 续跑：窗口静止时它不再变化，只按 windowChanged 触发会让积压永远留着。
        if (windowChanged || cleanupOpen) {
            cleanupOpen = SectionLifecycle.cleanup(server);
        }
        // 地形管线：调度器是地形侧唯一的每 tick 入口，准入、派发、重扫都在里面。
        Scheduler.tick();
    }
}
